import React from 'react';

const NavDivider = () => {
  return <li className="separator" />;
};

export default NavDivider;
