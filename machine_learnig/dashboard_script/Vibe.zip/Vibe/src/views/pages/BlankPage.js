import React from 'react';

const BlankPage = () => {
  return (
    <div>
      <span />
    </div>
  );
};

export default BlankPage;
